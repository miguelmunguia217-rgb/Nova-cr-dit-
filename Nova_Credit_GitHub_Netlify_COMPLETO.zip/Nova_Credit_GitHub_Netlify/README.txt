NOVA CREDIT HONDURAS — VERSIÓN PARA NETLIFY

Esta versión está preparada para:
- Publicarse directamente en Netlify.
- Guardar solicitudes en Netlify Forms.
- Mostrar una página de confirmación después del envío.
- Contactar por WhatsApp al +1 984-385-6934.
- Mostrar servicio al cliente +504 9689-9579.

PUBLICACIÓN
1. Descomprime este ZIP.
2. Sube el contenido de la carpeta nova_credit_web a Netlify.
3. Después del despliegue, envía una solicitud de prueba.
4. Para ver solicitudes:
   Netlify → proyecto → Forms → solicitudes-nova-credit.

IMPORTANTE
- No solicites contraseñas, PIN, códigos bancarios ni fotografías de tarjetas.
- Los textos legales son provisionales y deben revisarse en Honduras.
- El formulario no implica aprobación automática.
