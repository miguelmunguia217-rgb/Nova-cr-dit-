# Nova Credit Honduras

Sitio web oficial de Nova Credit Honduras.

## Contactos
- WhatsApp: +1 984-385-6934
- Servicio al cliente: +504 9689-9579
- Ubicación: San Francisco de la Paz, Olancho, Honduras

## Publicar con GitHub y Netlify
1. Sube todos los archivos de esta carpeta al repositorio.
2. En Netlify elige **Add new project → Import an existing project**.
3. Selecciona GitHub y este repositorio.
4. No uses comando de construcción.
5. En **Publish directory** escribe: `.`
6. Publica.

## Solicitudes
El formulario está configurado con Netlify Forms.

Para verlas:
**Netlify → Proyecto → Forms → solicitudes-nova-credit**

Los textos legales son provisionales y deben revisarse profesionalmente antes de manejar documentación sensible.
